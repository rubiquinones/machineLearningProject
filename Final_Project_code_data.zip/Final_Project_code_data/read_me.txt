All codes are in jupyter_notebook folder.
When you load the data, please load E1 data first, then do all processes; next load E2 data, then do all processes again.
In used_data folder, files "features_all.txt" and "labels_all.txt" are features and labels for E1 data;
files "features_all2.txt" and "labels_all2.txt" are features and labels for E2 data.